Steps to run:
largestconnected.sh "path to the dataset"
A file clustering.json would be created and would be visualised with the help of "collapse_auto_3d.html" 

example:
./largestconnected.sh ../EmailEnron.txt
